from os import system
def run(): system('cls||clear')
